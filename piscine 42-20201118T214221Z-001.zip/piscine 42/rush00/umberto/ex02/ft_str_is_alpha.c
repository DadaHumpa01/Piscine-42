/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: usavoia <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/26 16:15:22 by usavoia           #+#    #+#             */
/*   Updated: 2020/10/26 17:00:47 by usavoia          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_str_is_alpha(char *str)
{
	int i;
	int ritorno;

	i = 0;
	ritorno = 0;
	while (str[i] != '\0')
	{
		if (('@' < str[i] && str[i] < '[') || (96 < str[i] && str[i] < 123))
			i++;
		else
			break ;
	}
	ritorno = 0;
	if (str[i] == '\0')
		ritorno = 1;
	return (ritorno);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_memory.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: usavoia <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/27 15:21:28 by usavoia           #+#    #+#             */
/*   Updated: 2020/10/29 16:53:36 by usavoia          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	stampa(char c, int num)
{
	int		spazi;

	spazi = 0;
	if (num == -1)
		write(1, &c, 1);
	if (num >= 0)
	{
		spazi = 16 - num;
		while (spazi-- > 0)
			stampa(' ', -1);
	}
}

void	addr_hex(void *addr)
{
	char	addr_c[15];
	long	addr_l;
	int		i;

	addr_l = (long)addr;
	i = 0;
	while (addr_l > 0)
	{
		addr_c[i] = addr_l % 16;
		if (addr_c[i] < 10)
			addr_c[i] += '0';
		else
			addr_c[i] += 87;
		addr_l = addr_l / 16;
		i++;
	}
	while (i < 15)
	{
		addr_c[i] = '0';
		i++;
	}
	while (--i >= 0)
		stampa(addr_c[i], -1);
}

void	linea_hex(char c)
{
	unsigned char	cast_char;
	char			hex1;
	char			hex2;

	cast_char = (unsigned char)c;
	hex1 = cast_char / 16;
	hex2 = cast_char % 16;
	if (hex1 < 10)
		stampa(hex1 + '0', -1);
	else
		stampa(hex1 + 87, -1);
	if (hex2 < 10)
		stampa(hex2 + '0', -1);
	else
		stampa(hex2 + 87, -1);
}

void	stampa_linea(void *addr, int size)
{
	int		i;
	char	*addr_c;

	addr_c = (char *)addr;
	i = 0;
	while (i < size)
	{
		linea_hex(addr_c[i++]);
		if (i % 2 == 0)
			stampa(' ', -1);
	}
	stampa(' ', size);
	i = -1;
	while (++i < size)
	{
		if (addr_c[i] >= 32 && addr_c[i] <= 126)
		{
			if ((addr_c[i] == ' ') && (addr_c[i + 1] == ' '))
				i++;
			stampa(addr_c[i], -1);
		}
		else
			stampa('.', -1);
	}
}

void	*ft_print_memory(void *addr, unsigned int size)
{
	unsigned int offset;
	unsigned int num_char;

	num_char = 16;
	offset = 0;
	while (size > 0)
	{
		if (size < 16)
		{
			num_char = size;
			size = 0;
		}
		else
			size -= 16;
		addr_hex(addr + offset);
		stampa(':', -1);
		stampa(' ', -1);
		stampa_linea(addr + offset, num_char);
		stampa('\n', -1);
		offset += 16;
	}
	return (addr + offset);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr_non_printable.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: usavoia <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/27 14:50:29 by usavoia           #+#    #+#             */
/*   Updated: 2020/10/29 16:39:47 by usavoia          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	stampa(char c)
{
	write(1, &c, 1);
}

void	print_hex(char np)
{
	stampa("0123456789abcdef"[np / 16]);
	stampa("0123456789abcdef"[np % 16]);
}

void	ft_putstr_non_printable(char *str)
{
	int i;

	i = 0;
	while (str[i])
	{
		if ((str[i] < 32 && str[i] >= 0) || str[i] == 127)
		{
			stampa('\\');
			print_hex(str[i]);
		}
		else
			stampa(str[i]);
		i++;
	}
}

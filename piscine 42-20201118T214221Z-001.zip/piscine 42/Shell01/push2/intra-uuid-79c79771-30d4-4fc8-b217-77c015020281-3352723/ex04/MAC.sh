#!/bin/sh
ifconfig | grep ether | sed 's/ether//' | awk '{$1=$1};1'

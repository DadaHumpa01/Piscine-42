/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_params.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbrignon <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/11/08 11:57:11 by dbrignon          #+#    #+#             */
/*   Updated: 2020/11/08 12:04:37 by dbrignon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	putstr(char *str)
{
	while (*str)
	{
		write(1, str, 1);
		str++;
	}
}

int		main(int argc, char **argv)
{
	int aux;

	aux = 1;
	while (aux <= argc)
	{
		if (aux == argc)
		{
			break ;
		}
		putstr(argv[aux]);
		putstr("\n");
		aux++;
	}
}

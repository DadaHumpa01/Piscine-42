/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbrignon <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/26 17:00:26 by dbrignon          #+#    #+#             */
/*   Updated: 2020/10/26 17:10:40 by dbrignon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	print(int a, int b)
{
	char a0;
	char a1;
	char b0;
	char b1;

	a0 = a / 10 + '0';
	a1 = a % 10 + '0';
	b0 = b / 10 + '0';
	b1 = b % 10 + '0';
	write(1, &a0, 1);
	write(1, &a1, 1);
	write(1, " ", 1);
	write(1, &b0, 1);
	write(1, &b1, 1);
	if (a0 == '9' && a1 == '8')
	{
	}
	else
	{
		write(1, ", ", 2);
	}
}

void	ft_print_comb2(void)
{
	int a;
	int b;

	a = 0;
	b = 1;
	while (a <= 98)
	{
		b = a + 1;
		while (b <= 99)
		{
			print(a, b);
			b++;
		}
		a++;
	}
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbrignon <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/11/03 19:38:52 by dbrignon          #+#    #+#             */
/*   Updated: 2020/11/03 19:41:01 by dbrignon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

char	*ft_strcmp(char *dest, char *src, unsigned int nb)
{
	unsigned int i;

	i = 0;
	while (*dest)
	{
		dest++;
	}
	while (*src && nb > i)
	{
		*dest = *src;
		dest++;
		src++;
		i++;
	}
	printf("%s", dest);
	return (dest);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbrignon <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/11/03 19:10:13 by dbrignon          #+#    #+#             */
/*   Updated: 2020/11/03 19:33:33 by dbrignon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int		ft_strncmp(char *s1, char *s2, unsigned int n)
{
	unsigned int	i;
	unsigned int	ritorno;

	ritorno = 0;
	i = 0;
	while (s1[i])
	{
		if (i == n)
		{
			break ;
		}
		if (s1[i] != s2[i])
		{
			ritorno = s1[i] - s2[i];
			break ;
		}
		else
		{
			ritorno = 0;
		}
		i++;
	}
	return (ritorno);
}
